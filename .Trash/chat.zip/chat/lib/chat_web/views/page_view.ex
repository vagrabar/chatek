defmodule ChatWeb.PageView do
  use ChatWeb, :view
end
