defmodule ChatWeb.LayoutView do
  use ChatWeb, :view
end
