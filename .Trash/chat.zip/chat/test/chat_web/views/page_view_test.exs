defmodule ChatWeb.PageViewTest do
  use ChatWeb.ConnCase, async: true
end
